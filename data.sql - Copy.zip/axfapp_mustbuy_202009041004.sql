INSERT INTO public.axfapp_mustbuy (img,"name",trackid) VALUES 
('https://s8.gifyu.com/images/goods020.jpg','fish','10')
,('https://s8.gifyu.com/images/goods018.jpg','shrimp','11')
,('https://s8.gifyu.com/images/goods022.png','pork','12')
,('https://s8.gifyu.com/images/goods025.png','rip','30')
,('https://s8.gifyu.com/images/goods036.png','meatball','31')
,('https://s8.gifyu.com/images/goods028.png','skewer','32')
,('https://s8.gifyu.com/images/goods019.jpg','clam','33')
;