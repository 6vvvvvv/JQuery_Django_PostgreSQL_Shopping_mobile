INSERT INTO public.axfapp_maingood (img,"name",trackid) VALUES 
('https://s8.gifyu.com/images/mangue.jpg','mango','14')
,('https://s8.gifyu.com/images/framboise.jpg','framboise','15')
,('https://s8.gifyu.com/images/fraise.jpg','fraise','16')
,('https://s8.gifyu.com/images/citron-2.jpg','citron','17')
,('https://s8.gifyu.com/images/orange9354d91794c8ac3e.jpg','orange','13')
,('https://s8.gifyu.com/images/goods013.jpg','mandarine','18')
,('https://s8.gifyu.com/images/goods006.jpg','blum','19')
,('https://s8.gifyu.com/images/goods005.jpg','peach','20')
;