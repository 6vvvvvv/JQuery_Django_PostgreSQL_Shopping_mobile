INSERT INTO public.axfapp_main (img,"name",trackid) VALUES 
('https://s8.gifyu.com/images/rsz_seafoods_fish_food_shrimp_crayfish_542986_2560x1726.jpg','fish','4')
,('https://s8.gifyu.com/images/slide01.jpg','apple','1')
,('https://s8.gifyu.com/images/slide02.md.jpg','pear','2')
,('https://s8.gifyu.com/images/slide04.md.jpg','banana','3')
,('https://s8.gifyu.com/images/slide03.md.jpg','meat','5')
;