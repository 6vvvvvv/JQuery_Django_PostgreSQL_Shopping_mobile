INSERT INTO public.axfapp_cart ("userAccount",productid,productnum,productprice,"isChose",productimg,productname,orderid,"isDelete") VALUES 
('liuwei','119570',5,'5.00',true,'https://s8.gifyu.com/images/fish-stick.jpg','fish stick','0',false)
,('liuwei','119730',6,'106.80',true,'https://s8.gifyu.com/images/melon.jpg','melon','0',false)
,('11111111','109108',3,'26.70',true,'https://img9.doubanio.com/view/photo/m/public/p2600563837.webp','yogurt','>1589066861',true)
,('11111111','109108',4,'35.60',true,'https://img9.doubanio.com/view/photo/m/public/p2600563837.webp','yogurt','1589073476.4975922',true)
,('testaccount','109108',5,'44.50',true,'https://img9.doubanio.com/view/photo/m/public/p2600563837.webp','yogurt','1598927087.1065292',true)
,('testaccount','109108',5,'44.50',true,'https://img9.doubanio.com/view/photo/m/public/p2600563837.webp','yogurt','1589230816.0689163',true)
,('liuwei','109108',7,'62.30',true,'https://s8.gifyu.com/images/yogurt.jpg','yogurt','1598927087.1065292',true)
,('liuwei','109108',4,'35.60',true,'https://s8.gifyu.com/images/yogurt.jpg','yogurt','1598957073.1364157',true)
,('liuwei','109108',24,'213.60',true,'https://s8.gifyu.com/images/yogurt.jpg','yogurt','1599035805.225318',true)
,('liuwei','119570',4,'4.00',true,'https://s8.gifyu.com/images/fish-stick.jpg','fish stick','1599035805.225318',true)
;
INSERT INTO public.axfapp_cart ("userAccount",productid,productnum,productprice,"isChose",productimg,productname,orderid,"isDelete") VALUES 
('liuwei','109108',7,'62.30',true,'https://s8.gifyu.com/images/yogurt.jpg','yogurt','0',false)
;