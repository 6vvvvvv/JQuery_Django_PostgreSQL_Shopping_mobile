INSERT INTO public.axfapp_goods (productid,productimg,productname,onefree,specifics,price,originprice,categoryid,childcid,childcidname,detailid,inventory,soldnum) VALUES 
('119730','https://s8.gifyu.com/images/melon.jpg','melon','0','600-800g',17.8,19.9,'104747','104748','fresh','4858',4,100000000)
,('119731','https://s8.gifyu.com/images/citron.jpg','citron','0','180-220g',5.9,6.8,'104747','104748','fresh','4858',10,100000000)
,('118344','https://s8.gifyu.com/images/gum.jpg','chewing gum 56g','0','56g',10,10,'103541','103545','candy','4858',10,1)
,('109108','https://s8.gifyu.com/images/yogurt.jpg','yogurt','1','250g',8.9,15,'104749','103537','yogurt','4858',3,100003903)
,('119570','https://s8.gifyu.com/images/fish-stick.jpg','fish stick','1','32g',1,1,'104749','103543','puffed food','4858',5,100003541)
,('91599','https://s8.gifyu.com/images/cocktail.jpg','cocktail','0','275ml',13,13,'103549','103555','wine','4858',10,8)
,('118141','https://s8.gifyu.com/images/jus-de-orange.jpg','orance juice','0','330ml*24',105,105,'103549','104503','package','4858',10,9)
,('69677','https://s8.gifyu.com/images/jus-de-anana.jpg','pineapple juice','0','500ml',5,5,'103549','104489','protein','4858',10,10)
,('99972','https://s8.gifyu.com/images/jus-de-peche.jpg','peach juice','0','490ml',8,7,'103549','103551','juice','4858',10,10)
,('99970','https://s8.gifyu.com/images/jus-de-mangue.jpg','mango juice','0','490ml',7.5,7,'103549','103551','juice','4858',10,10)
;
INSERT INTO public.axfapp_goods (productid,productimg,productname,onefree,specifics,price,originprice,categoryid,childcid,childcidname,detailid,inventory,soldnum) VALUES 
('5323','https://s8.gifyu.com/images/poulet.jpg','chips beef flavor','0','60g',4,4,'103541','103543','puffed food','4858',10,1)
,('117075','https://s8.gifyu.com/images/barbecue.jpg','chips barbecue flavor','0','110g',10,10,'103541','103543','puffed food','4858',10,1)
,('5248','https://s8.gifyu.com/images/fromage.jpg','chips cheese flavor','0','104g',9,9,'103541','103543','puffed food','4858',10,1)
,('5675','https://s8.gifyu.com/images/Ladyfinger.jpg','biscuit1 168.0g','0','168g',5.5,5.5,'103541','103544','biscuit','4858',10,1)
,('3593','https://s8.gifyu.com/images/biscuit2.jpg','biscuit 60.0g','0','60g',5,4.5,'103541','103544','biscuit','4858',10,0)
,('8556','https://s8.gifyu.com/images/biscuit1.jpg','biscuit 65.0g','0','65g',6,4.5,'103541','103544','biscuit','4858',10,0)
,('6426','https://s8.gifyu.com/images/biscuit3.jpg','biscuit 170g','0','170g',12,12,'103541','103544','biscuit','4858',10,0)
,('7914','https://s8.gifyu.com/images/chewinggum2.jpg','chewing gum 101.0g','0','101g',16,16,'103541','103545','candy','4858',10,1)
,('3966','https://s8.gifyu.com/images/biscuit.jpg','biscuit 45.0g','0','45g',6,6,'103541','103544','biscuit','4858',10,0)
;