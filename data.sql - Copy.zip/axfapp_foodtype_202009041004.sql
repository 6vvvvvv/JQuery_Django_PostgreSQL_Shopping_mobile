INSERT INTO public.axfapp_foodtype (typeid,typename,childtypenames,typesort) VALUES 
('103575','Household','ALL:0',10)
,('103569','Condiment','ALL:0',9)
,('103557','Instant','ALL:0',8)
,('103581','Cooked','ALL:0',7)
,('103532','Fruit','ALL:0',6)
,('103536','Breakfast','ALL:0',5)
,('104958','Icecream','ALL:0',11)
,('104749','Hot','ALL:0',1)
,('104747','Fresh','ALL:0',2)
,('103541','Snack','ALL:0#biscuit:103544#puffed food:103543#candy:103545',3)
;
INSERT INTO public.axfapp_foodtype (typeid,typename,childtypenames,typesort) VALUES 
('103549','Drink','ALL:0#wine:103555#juice:103551#package:104503#protein:104489',4)
;