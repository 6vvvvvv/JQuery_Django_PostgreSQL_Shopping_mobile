INSERT INTO public.axfapp_user ("userAccount","userPasswd","userName","userPhone","userAddress","userIcon","userRank","userToken") VALUES 
('liuwei','05875663','liuwei','0769183732','427,cours emile zola,villeurbanne','C:\Users\liuwg\learngit\jQuery_django_postgresql_mobileshopping\axf\media/icons\liuwei.jpg',0,'1598984437.7216625')
;