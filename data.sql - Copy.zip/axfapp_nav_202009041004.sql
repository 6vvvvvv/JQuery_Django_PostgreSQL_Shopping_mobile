INSERT INTO public.axfapp_nav (img,"name",trackid) VALUES 
('https://s8.gifyu.com/images/2ebea9f1c75adeacdda4ccf745befdb4.png','home','6')
,('https://s8.gifyu.com/images/92ef8324d19ede77c471bf3bba40b4bc.png','like','7')
,('https://s8.gifyu.com/images/6bfcef1378af6e6ba7ef1b1901939717.png','aftersale','8')
,('https://s8.gifyu.com/images/884385952053a607bffb49cacfae3e82.png','vip','9')
;